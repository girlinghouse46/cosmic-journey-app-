# Cosmic Journey Application

## Overview

This is a full-stack web application called "Cosmic Journey" built with React and Express. It's an interactive Matrix-themed experience that explores how life operates like code and provides two paths to escape the simulation. Users can choose between external reality hacking or inner consciousness debugging to achieve transcendence from programmed reality. The application uses a modern TypeScript stack with shadcn/ui components and Matrix-style visual programming elements.

## User Preferences

Preferred communication style: Simple, everyday language.
Matrix Theme: Show how life is code and provide paths to escape the simulation through programming wisdom.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom cosmic theme variables
- **Animations**: Framer Motion for smooth transitions and effects
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: In-memory storage with fallback to PostgreSQL sessions
- **Development**: Hot reload with tsx

## Key Components

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL with Neon Database provider
- **Schema**: Located in `shared/schema.ts` for type sharing between client and server
- **Migrations**: Managed through `drizzle-kit` with migrations stored in `./migrations`
- **Tables**: 
  - `users` - Basic user authentication (id, username, password)
  - `journeys` - Cosmic journey sessions with progress tracking (sessionId, selectedPath, currentScreen, completedAt, constellationData)

### Authentication & Storage
- **Storage Interface**: Abstracted through `IStorage` interface in `server/storage.ts`
- **Current Implementation**: In-memory storage (`MemStorage`) for development
- **Future**: Ready for PostgreSQL implementation with existing Drizzle schema

### UI Components
- **Component Library**: Complete shadcn/ui implementation with 40+ components
- **Theme**: Custom cosmic theme with dark space colors and gradients
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: Built on Radix UI primitives for ARIA compliance

### Application Features
- **Landing Page**: Matrix-themed entry point with "Wake Up from the Matrix" concept and code-style awakening loop
- **Interactive Journey**: Multi-step Matrix escape experience with two distinct path options:
  - **Path.EXTERNAL_REALITY**: Hack the cosmic matrix and understand universal quantum algorithms
  - **Path.INNER_AWAKENING**: Debug consciousness and rewrite inner code to transcend limitations
- **Branch Experience**: Programming-heavy content with syntax-highlighted code blocks showing Matrix escape techniques
- **Climactic Scene**: Matrix-themed constellations ("The Reality Hacker" and "The Consciousness Debugger") with escape confirmation
- **Star Field Animation**: Procedurally generated animated background throughout the experience
- **Journey Management**: Complete flow control with navigation and reset capabilities
- **Database Persistence**: All journey progress automatically saved to PostgreSQL database
- **Session Management**: Each user session tracked with unique session IDs
- **Admin Dashboard**: View all stored journeys at `/admin` route
- **Programming Integration**: Reflection path uses coding concepts to explore how inner growth reflects in the world
- **Responsive Design**: Works across desktop and mobile devices

## Data Flow

1. **Client Requests**: React components use TanStack Query for API calls
2. **API Layer**: Express routes handle HTTP requests (prefix: `/api`)
3. **Storage Layer**: Abstract storage interface allows for different implementations
4. **Database**: Drizzle ORM manages PostgreSQL interactions
5. **Response**: JSON responses sent back through Express middleware

### State Management
- **Server State**: TanStack Query with automatic caching and refetching
- **Local State**: React hooks for component-level state
- **Form State**: React Hook Form with Zod validation (configured but not actively used)

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database queries
- **@tanstack/react-query**: Server state management
- **framer-motion**: Animation library
- **wouter**: Lightweight React router

### UI Dependencies
- **@radix-ui/***: Unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant generation
- **clsx**: Conditional className utility

### Development Dependencies
- **vite**: Build tool and dev server
- **tsx**: TypeScript execution for Node.js
- **drizzle-kit**: Database migration tool
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with hot reload
- **Backend**: tsx for TypeScript execution with auto-restart
- **Database**: Requires `DATABASE_URL` environment variable
- **Command**: `npm run dev` starts both frontend and backend

### Production Build
- **Frontend**: Vite builds to `dist/public`
- **Backend**: esbuild bundles server to `dist/index.js`
- **Database**: `npm run db:push` applies schema changes
- **Start**: `npm start` runs production server

### Environment Requirements
- **Node.js**: ES modules support required
- **Database**: PostgreSQL connection via `DATABASE_URL`
- **Dependencies**: All production dependencies bundled

### File Structure
```
client/          # React frontend application
server/          # Express backend application
shared/          # Shared TypeScript types and schemas
migrations/      # Database migration files
dist/           # Production build output
```

The application is designed for easy deployment on platforms like Replit, with automatic database provisioning and built-in development tools.