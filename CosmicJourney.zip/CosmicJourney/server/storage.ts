import { type User, type InsertUser, type Journey, type InsertJourney, type UpdateJourney } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Journey methods
  getJourney(id: string): Promise<Journey | undefined>;
  getJourneyBySessionId(sessionId: string): Promise<Journey | undefined>;
  createJourney(journey: InsertJourney): Promise<Journey>;
  updateJourney(id: string, updates: UpdateJourney): Promise<Journey | undefined>;
  getRecentJourneys(limit?: number): Promise<Journey[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private journeys: Map<string, Journey>;

  constructor() {
    this.users = new Map();
    this.journeys = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getJourney(id: string): Promise<Journey | undefined> {
    return this.journeys.get(id);
  }

  async getJourneyBySessionId(sessionId: string): Promise<Journey | undefined> {
    return Array.from(this.journeys.values()).find(
      (journey) => journey.sessionId === sessionId,
    );
  }

  async createJourney(insertJourney: InsertJourney): Promise<Journey> {
    const id = randomUUID();
    const now = new Date();
    const journey: Journey = { 
      id,
      sessionId: insertJourney.sessionId,
      selectedPath: insertJourney.selectedPath ?? null,
      currentScreen: insertJourney.currentScreen ?? 'landing',
      completedAt: insertJourney.completedAt ?? null,
      constellationData: insertJourney.constellationData ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.journeys.set(id, journey);
    return journey;
  }

  async updateJourney(id: string, updates: UpdateJourney): Promise<Journey | undefined> {
    const journey = this.journeys.get(id);
    if (!journey) return undefined;

    const updatedJourney: Journey = {
      ...journey,
      ...updates,
      updatedAt: new Date(),
    };
    this.journeys.set(id, updatedJourney);
    return updatedJourney;
  }

  async getRecentJourneys(limit: number = 10): Promise<Journey[]> {
    return Array.from(this.journeys.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
