# 🚀 Deploy to Railway - Step by Step

## What You Need
1. Your code on GitHub (if not already there)
2. Railway account (free at railway.app)

## Step 1: Get Your Code on GitHub

If your code isn't on GitHub yet:
```bash
# In your terminal (or use Replit's Git tools):
git init
git add .
git commit -m "Initial commit - Cosmic Journey Matrix app"
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
git push -u origin main
```

Or use Replit's built-in GitHub export feature.

## Step 2: Deploy on Railway

### A. Sign Up & Connect
1. Go to [railway.app](https://railway.app)
2. Click "Login" and sign up with GitHub
3. Authorize Railway to access your repositories

### B. Create New Project
1. Click "New Project"
2. Click "Deploy from GitHub repo"
3. Select your cosmic journey repository
4. Railway will automatically detect it's a Node.js app

### C. Add PostgreSQL Database
1. In your project dashboard, click "New Service"
2. Click "Database" → "PostgreSQL"
3. Railway automatically creates DATABASE_URL environment variable

### D. Configure Your App Service
1. Click on your app service (not the database)
2. Go to "Settings" tab
3. Scroll to "Environment Variables"
4. Verify these are set:
   - `DATABASE_URL` (auto-set from PostgreSQL service)
   - `NODE_ENV` → `production`
   - `PORT` (auto-set by Railway)

### E. Initial Database Setup
1. Wait for deployment to complete (watch "Deployments" tab)
2. Once live, click on your app service
3. Go to "Deployments" tab → click latest deployment
4. Click "View Logs" to see if everything started correctly
5. Run database migration:
   - In Railway dashboard, go to app service
   - Click "Settings" → "Commands"
   - Add one-time command: `npm run db:push`
   - Or use Railway CLI: `railway run npm run db:push`

## Step 3: Access Your Live App

Your app will be available at:
- `https://YOUR-APP-NAME.railway.app`
- Railway provides the URL in your dashboard

## Step 4: Test Your Deployment

1. Visit your live URL
2. Try both Matrix escape paths:
   - External Reality (Wonder path)
   - Inner Awakening (Reflection path)
3. Verify database saves journey progress
4. Check admin panel at `/admin`

## Environment Variables Reference

Your app needs these (Railway sets automatically):
```
DATABASE_URL=postgresql://... (from PostgreSQL service)
NODE_ENV=production
PORT=3000 (Railway assigns this)
```

## Troubleshooting

### Build Issues
- Check "Build Logs" in Railway dashboard
- Ensure Node.js version compatibility

### Database Connection
- Verify PostgreSQL service is running
- Check DATABASE_URL is properly linked

### App Won't Start
- Check "Deploy Logs" for errors
- Verify `npm start` command works locally

## Cost
- Railway gives you $5 free credit
- Your app will use approximately $1-2/month
- Free credit lasts 2-3 months for most small apps

## Your Live Matrix Experience
Once deployed, people worldwide can experience your cosmic journey that demonstrates how life operates like code - choosing between external reality hacking and inner consciousness debugging to escape the simulation!